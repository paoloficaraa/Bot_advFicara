/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advficara;

import TelegramBots.TelegramBotsAPI;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.parser.ParseException;

/**
 *
 * @author ficara_paolo
 */
public class ThreadListen extends Thread {
    
    private String apiToken;
    private TelegramBotsAPI api;
    
    public ThreadListen(String apiToken, TelegramBotsAPI api){
        this.apiToken = apiToken;
        this.api = api;
    }
    
    @Override
    public void run(){
        String latestMessage = "";
        while(true){
            try {
                if(api.getUpdatesFromTelegram(apiToken).equals(latestMessage)){
                    //api.sendToTelegram("", apiToken, apiToken);
                }
                if(api.getUpdatesFromTelegram(apiToken).charAt(0) == '/'){
                    if(api.getUpdatesFromTelegram(apiToken).equals("/città")){
                        
                    }
                }
            } catch (ParseException ex) {
                Logger.getLogger(ThreadListen.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
